/**
 * The TreeNode class is used to establish all of the data required for each
 * item in shop to contain e.g name, id, cost
 *
 * @author Maks Kijewski
 * @version 22/02/2025
 */
public class TreeNode
{
    /**
     * FIELDS
     */
    private int ID; //index
    private String name;
    private double cost;
    private int quantity;
    private TreeNode left;
    private TreeNode right;
    /**
     * CONSTRUCTOR
     * This constructor sets all the variables to their default state
     */
    public TreeNode()
    {
        ID = 0;
        name = "";
        cost = 0.00;
        quantity = 1;
        left = null;
        right = null;
    }
    /**
     * SET_ID METHOD
     * This method will allow the user to set the ID of an item
     */
    public void setID(int id)
    {
        ID = id;
    }
    /**
     * GET_ID METHOD
     * This method will return the value of the ID for a given node/item
     */
    public int getID()
    {
        return ID;
    }
    /**
     * SET_NAME METHOD
     * This method will allow the user to set the name of an item
     */
    public void setName(String n)
    {
        name = n;
    }
    /**
     * GET_NAME METHOD
     * This method will return the value of the name for a given node/item
     */
    public String getName()
    {
        return name;
    }
    /**
     * SET_COST METHOD
     * This method will allow the user to set the cost of an item
     */
    public void setCost(double c)
    {
        cost = c;
    }
    /**
     * GET_COST METHOD
     * This method will return the value of the cost for a given node/item
     */
    public double getCost()
    {
        return cost;
    }
    /**
     * SET_QUANTITY METHOD
     * This method will allow the program to set the quantity of an item
     */
    public void setQuantity(int q)
    {
        quantity = q;
    }
    /**
     * GET_QUANTITY METHOD
     * This method will return the value of the quantity for a given node/item
     */
    public int getQuantity()
    {
        return quantity;
    }
    /**
     * SET_LEFT METHOD
     * This method will allow the program to set a node to the left node of a 
     * parent node
     */
    public void setLeft(TreeNode leftC)
    {
        left = leftC;
    }
    /**
     * GET_LEFT METHOD
     * This method will return the left child node
     */
    public TreeNode getLeft()
    {
        return left;
    }
    /**
     * SET_RIGHT METHOD
     * This method will allow the program to set a node to the right node of a 
     * parent node
     */
    public void setRight(TreeNode rightC)
    {
        right = rightC;
    }
    /**
     * GET_RIGHT METHOD
     * This method will return the right child node
     */
    public TreeNode getRight()
    {
        return right;
    }
    /**
     * GET_DATA METHOD
     * This method will return all of the variables and their corresponding
     * values a item can contain
     */
    public String getData()
    {
        return "ID: " + getID() + " Name: " + getName() + " Cost: £" + getCost() + " Quantity: " + getQuantity();
    }
}
