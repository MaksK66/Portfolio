/**
 * This class contains all of the important methods that are required to 
 * run the shop relying on the TreeNode class for the methods to be able 
 * to function
 *
 * @author Maks Kijewski
 * @version 22/02/2025
 */
import java.util.Queue;
import java.util.LinkedList;
public class Tree
{
    /**
     * FIELDS
     */
    private TreeNode root;
    private double total;
    /**
     * CONSTRUCTOR
     * This constructor is used to create an empty tree/shop
     */
    public Tree()
    {
        root = null;
    }
    /**
     * SET_ROOT METHOD
     * This method will allow the program to set any node to be the root node
     */
    public void setRoot(TreeNode newRootNode)
    {
        root = newRootNode;
    }
    /**
     * GET_ROOT METHOD
     * This method will return the current root node
     */
    public TreeNode getRoot()
    {
        return root;
    }
    /**
     * ADD_NODE METHOD
     * This method will add a node in the tree by comparing the new id to the
     * current id, with checks for if a node with the id already exists and
     * if the tree is empty
     */
    public void addNode(int id, String n, double c)
    {
        TreeNode t = new TreeNode();
        t.setID(id);
        t.setName(n);
        t.setCost(c);
        if (root == null)
        {
            root = t;
            System.out.println("Added root node: " + t.getID());
        }
        else
        {
            if (find(id) != null)
            {
                System.out.println("Node is already in the tree");
            }
            else
            {
                TreeNode current = root;
                TreeNode previous = null;
                while (current != null)
                {
                    previous = current;
                    if (id < current.getID())
                    {
                        current = current.getLeft();
                        System.out.println("Added node to left of " + previous.getID() + ": " + t.getID());
                    }
                    else
                    {
                        current = current.getRight();
                        System.out.println("Added node to right of " + previous.getID() + ": " + t.getID());
                    }
                }
                if (id < previous.getID())
                {
                    previous.setLeft(t);
                }
                else
                {
                    previous.setRight(t);
                }
            }
        }
    }
    /**
     * ADD_NODE_2 METHOD
     * This method adds a node but also has been changed to support the 
     * quantity feature as instead of stopping after detecting the same id
     * the program will add 1 to the quantity of the item with added checks to
     * ensure the right cost and name is used for the item with the same id
     */
    public void addNode2(int id, String n, double c)
    {
        TreeNode existingNode = find(id);
        if (existingNode != null)
        {
            if (c != existingNode.getCost())
            {
                System.out.println("ERROR: cost entered doesnt match item");
                return;
            }
            else if (!n.equals(existingNode.getName()))
            {
                System.out.println("ERROR: name entered doesnt match item");
                return;
            }
            else
            {
                existingNode.setQuantity(existingNode.getQuantity() + 1);
                System.out.println("Increased quantity of node: " + existingNode.getID());
                return;
            }  
        }
        TreeNode t = new TreeNode();
        t.setID(id);
        t.setName(n);
        t.setCost(c);
        if (root == null)
        {
            root = t;
            System.out.println("Added root node: " + t.getID());
        }
        else
        {
            TreeNode current = root;
            TreeNode previous = null;
            while (current != null)
            {
                previous = current;
                if (id < current.getID())
                {
                    current = current.getLeft();
                    System.out.println("Added node to left of " + previous.getID() + ": " + t.getID());
                }
                else
                {
                    current = current.getRight();
                    System.out.println("Added node to right of " + previous.getID() + ": " + t.getID());
                }
            }
            if (id < previous.getID())
            {
                previous.setLeft(t);
            }
            else
            {
                previous.setRight(t);
            }
            System.out.println("Added node: " + t.getData());
        }
    }
    /**
     * DISPLAY_TREE METHOD
     * This method will display the binary tree/shop horizontally by using 
     * a recursive technique
     */
    public void displayTree(TreeNode p, String indent)
    {
        if (p != null)
        {
            displayTree(p.getRight(), indent + "\t");
            System.out.println(indent + p.getData());
            displayTree(p.getLeft(), indent + "\t");
        }
    }    
    /**
     * DISPLAY_ITEMS METHOD
     * This method will display the items in shop in ID order
     */
    public void displayItems(TreeNode p)
    {
        if (p != null)
        {
            displayItems(p.getRight());
            System.out.println(p.getData());
            displayItems(p.getLeft());
        }
    }
    /**
     * GET_TOTAL_COST METHOD
     * This method will calculate the total cost of items by working its way
     * through the tree whilst also taking the quantity of each of the items
     * in mind by multiplying it with the cost
     */
    public void getTotalCost(TreeNode p)
    {
        if (p != null)
        {
            getTotalCost(p.getRight());
            total += (p.getCost() * p.getQuantity());
            getTotalCost(p.getLeft());
        }
    }  
    /**
     * SHOW_TREE METHOD
     * This method will call the DISPLAY_TREE method whilst also providing
     * a value for the indent variable
     */
    public void showTree()
    {   
        String indent = "";
        displayTree(root, indent);
    }
    /**
     * SHOW_ITEMS METHOD
     * This method will call the DISPLAY_ITEMS method
     */
    public void showItems()
    {   
        displayItems(root);
    }
    /**
     * GET_TOTAL METHOD
     * This method will call the GET_TOTAL_COST method and print the total
     * value
     */
    public void getTotal()
    {   
        getTotalCost(root);
        System.out.println("Total cost of all the items: £" + total);
    }
    /**
     * FIND METHOD
     * This method will attempt to find the node with the matching id by 
     * progressing through the tree and comparing the current id to the one
     * the user wishes to search for
     */
    public TreeNode find(int IDToLookFor)
    {
        TreeNode current = root;
        while (current != null)
        {
            if (IDToLookFor == current.getID())
            {
                return current;
            }
            else if (IDToLookFor < current.getID())
            {
                current = current.getLeft();
            }
            else
            {
                current = current.getRight();
            }
        }
        return null;
    }
    /**
     * REMOVE METHOD
     * This method will firstly find what type of node will be deleted by 
     * progressing through the tree whilst comparing the id's, then by checking
     * for the state of the left and right child of the node that will be deleted
     * the program will call the appropriate method to actually delete that node
     * 
     * However if the program detects that the current node to be deleted has a
     * quantity greater than 1 it will only remove 1 from the quantity variable
     * instead
     */
    public void remove(int id, TreeNode parent, TreeNode node)
    {
        if (node == null)
        {
            System.out.println("Item not found");
            return;
        }
        if (id < node.getID())
        {
            remove(id, node, node.getLeft());
        }
        else if (id > node.getID())
        {
            remove(id, node, node.getRight());
        }
        else
        {
            if (node.getQuantity() > 1)
            {
                node.setQuantity(node.getQuantity() - 1);
                System.out.println("Decreased quantity of node: " + node.getID());
            }
            else
            {
                if (node.getLeft() == null && node.getRight() == null)
                {
                    removeLeafNode(parent, node);
                }
                else if (node.getLeft() == null || node.getRight() == null)
                {   
                    removeOneCNode(parent, node);
                }
                else
                {
                    removeTwoCNode(parent, node);
                }
                System.out.println("Removed Node: " + node.getID());
            }
        }
    }
    /**
     * REMOVE_LEAF_NODE METHOD
     * This method will check whether the node to be deleted is on the left 
     * or right side of its parent node and will be deleted accordingly
     * 
     * This method also checks for if the parent is null which would mean the 
     * only node that exists would be the root, therefore deleting the root node
     */
    public void removeLeafNode(TreeNode parent, TreeNode nodeToDelete)
    {
        if (parent == null)
        {
            root = null;
        }
        else if (parent.getLeft() == nodeToDelete)
        {
            parent.setLeft(null);
        }
        else 
        {
            parent.setRight(null);
        }
    }
    /**
     * REMOVE_ONE_C_NODE METHOD
     * This method will check which side the one child is located on with regards
     * to the node that'll be deleted, and will also check which side the node to
     * be deleted is with regards to to its parent and then will allocate the child
     * to the nodes parent instead accordingly
     * 
     * This method also checks for if the parent node is null which would then mean
     * that the node to be deleted would be the root, replacing the root with its 
     * child
     */
    public void removeOneCNode(TreeNode parent, TreeNode nodeToDelete) 
    {
        TreeNode childToAdopt;
        if (nodeToDelete.getLeft() != null)
        {
            childToAdopt = nodeToDelete.getLeft();
        }
        else 
        {
            childToAdopt = nodeToDelete.getRight();
        }
        if (parent == null)
        {
            root = childToAdopt;
        }
        else if (parent.getLeft() == nodeToDelete)
        {
            parent.setLeft(childToAdopt);
        }
        else
        {
            parent.setRight(childToAdopt);
        }
    }
    /**
     * FIND_RIGHT_MOST METHOD
     * This method find the right most node based on the node given in the
     * parameter
     */
    public TreeNode findRightMost(TreeNode node)
    {
        while (node.getRight() != null)
        {
            node = node.getRight();
        }
        return node;
    }
    /**
     * REMOVE_TWO_C_NODE METHOD
     * This method will call the FIND_RIGHT_MOST method to get that node, the 
     * node to be deleted's data then gets replaced with the right mosts data
     * where then the program calls the REMOVE method with the new inputs as
     * parameters so the right most node will get deleted as it is a leaf node
     * 
     * This method will also work when the root node is the node to be deleted
     */
    public void removeTwoCNode(TreeNode parent, TreeNode nodeToDelete)
    {
        TreeNode rightMost = findRightMost(nodeToDelete.getLeft());
        nodeToDelete.setID(rightMost.getID());
        nodeToDelete.setName(rightMost.getName());
        nodeToDelete.setCost(rightMost.getCost());
        remove(rightMost.getID(), nodeToDelete, nodeToDelete.getLeft());
    }
    /**
     * DISPLAY_LEVEL_ORDER METHOD
     * This method will print out all of the node and their data in the tree
     * in level order by using a queue, the program firstly adds the root node
     * and then it progresses through the tree in a level order, using the .poll()
     * method to retrieve and remove the head node in the queue
     */
    public void displayLevelOrder()
    {
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        if (root == null)
        {
            return;
        }
        while (!queue.isEmpty())
        {
            TreeNode node = queue.poll();
            System.out.println(node.getData());
            if (node.getLeft() != null)
            {
                queue.add(node.getLeft());
            }
            if (node.getRight() != null)
            {
                queue.add(node.getRight());
            }
        }
    }
}
