
/**
 * This class uses Sets and contains all the relevant methods to be able to 
 * simulate a lottery 
 *
 * @author Maks Kijewski
 * @version 08/02/2025
 */
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Random;
import java.util.InputMismatchException;
public class Lottery
{
   /**
    * FIELDS
    */
   private Set<Integer> lotteryNumbers;
   private Set<Integer> userNumbers;
   private Iterator<Integer> itr1; //lottery numbers
   private Iterator<Integer> itr2; //user numbers
   private Iterator<Integer> itr3; //copy of user numbers
   private int nextNum; //to cycle through the sets
   private static int LOTTERY_MAX;
   private static final int LOTTERY_MIN = 1;
   private int winnings;
   private int balance;
   private int matchChecker = 0; //to count the number of matches
   /**
    * THE CONSTRUCTOR
    * To create new instances of the two main sets
    */
   public Lottery()
   {
       lotteryNumbers = new HashSet<>();
       userNumbers = new HashSet<>();
   }
   /**
    * ADD_LOTTERY_NUMBERS METHOD
    * This will fill the lottery set with hardcoded values for testing
    */
   public void addLotteryNumbers() //hardcoded
   {
       lotteryNumbers.clear();
       LOTTERY_MAX = 100; // 25, 50 or 100 only 
       lotteryNumbers.add(1);
       lotteryNumbers.add(2);
       lotteryNumbers.add(3);
       lotteryNumbers.add(4);
       lotteryNumbers.add(5);
       lotteryNumbers.add(6);
   }
   /**
    * ADD_USERS_NUMBERS METHOD
    * This will fill the user set with hardcoded values for testing
    */
   public void addUserNumbers() //hardcoded
   {
       userNumbers.clear();
       userNumbers.add(1);
       userNumbers.add(2);
       userNumbers.add(3);
       userNumbers.add(4);
       userNumbers.add(5);
       userNumbers.add(6);
   }
   /**
    * LOTTERY_RANGE METHOD
    * This method will prompt the user to choose which version of the lottery they
    * wish to play and saves this in the LOTTERY_MAX variable
    */
   public void lotteryRange()
   {
       Scanner scale = new Scanner(System.in);
       int choice = 0;
       do
       {
       System.out.println("Choose your lottery range");
       System.out.println("Press 1. for the small lottery (1 to 25) (Win up to £200000!) (Ticket price: £1)");
       System.out.println("Press 2. for the normal lottery (1 to 50) (Win up to £1000000!!) (Ticket price: £2)");
       System.out.println("Press 3. for the HUGE lottery (1 to 100) (Win up to £5000000!!!) (Ticket price: £4)");
       try
       {
           choice = scale.nextInt();
       }
       catch (InputMismatchException e) 
       {
           System.out.println("ERROR: Wrong type of input!!! must be an integer");
           scale.next();
           continue;
       }
       switch (choice)
       {
           case 1: 
               LOTTERY_MAX = 25;
               System.out.println("You have chosen the small lottery");
               break;
           case 2: 
               LOTTERY_MAX = 50;
               System.out.println("You have chosen the normal lottery");
               break;
           case 3: 
               LOTTERY_MAX = 100;
               System.out.println("You have chosen the HUGE lottery");
               break;
           default:  
               System.out.println("Input Error");
               break;
       }
       }
       while (choice != 1 && choice != 2 && choice != 3);
       scale.close();
   }
   /**
    * ADD_OWN_USER_NUMBERS METHOD
    * This method will prompt the user to enter 6 numbers using a checker and if 
    * statements to ensure the numbers will enter the set correctly
    */
   public void addOwnUserNumbers() 
   {
       Scanner num = new Scanner(System.in);
       int numberChecker = 1;
       int x = 0;
       userNumbers.clear();
       System.out.println("Enter your first number");
       while (numberChecker <= 6)
       {
           try 
           {
               x = num.nextInt();
           }
           catch (InputMismatchException e)
           {
               System.out.println("ERROR: Wrong type of input!!! must be an integer");
               System.out.println("Try again!");
               num.next();
               continue;
           }
           if (userNumbers.contains(x))
           {
               System.out.println("You cannot use the same number twice!");
               continue;
           }
           if (x < LOTTERY_MIN || x > LOTTERY_MAX)
           {
               System.out.println("ERROR: number out of bounds of the lottery");
               continue;
           }
           userNumbers.add(x);
           numberChecker++;
           if (numberChecker <= 6)
           {
               System.out.println("Enter your next number");
           }
           if (numberChecker > 6)
           {
               System.out.println(" ");
           }
       }
       num.close();
   }
   /**
    * ADD_RANDOM_LOTTERY METHOD
    * This method uses the Random object to generate 6 numbers in the lottery set
    * within the boundary of the lottery range
    */
   public void addRandomLottery()
   {
       Random numGen = new Random();
       lotteryNumbers.clear();
       while (lotteryNumbers.size() < 6)
       {
           int x = numGen.nextInt(LOTTERY_MAX) + LOTTERY_MIN;
           lotteryNumbers.add(x);
       }
   }
   /**
    * DISPLAY METHOD
    * This method will print out the lottery and user set using the Iterator object
    */
   public void display()
   {
       itr1 = lotteryNumbers.iterator();
       itr2 = userNumbers.iterator();
       System.out.println("Lottery Numbers:");
       System.out.print("[ ");
       while (itr1.hasNext())
       {
           nextNum = itr1.next();
           System.out.print(nextNum + " ");
       }
       System.out.print("]");
       System.out.println(" ");
       System.out.println("User Numbers:");
       System.out.print("[ ");
       while (itr2.hasNext())
       {
           nextNum = itr2.next();
           System.out.print(nextNum + " ");
       }
       System.out.print("]");
       System.out.println(" ");
   }
   /**
    * GET_WINNINGS METHOD
    * This method will return the value of the winnings variable
    */
   public int getWinnings()
   {
       return winnings;
   }
   /**
    * DISPLAY_WINNINGS METHOD
    * This method will print out the users winnings of the lottery
    */
   public void displayWinnings()
   {
       System.out.println("Your winnings: £" + getWinnings());
   }
   /**
    * RESET_WINNINGS METHOD
    * This method will set the winnings to 0 which is mostly utilised in the autoplay
    * method to avoid winnings to add up
    */
   public void resetWinnings()
   {
       winnings = 0;
   }
   /**
    * GET_BALANCE METHOD
    * This method will return the value of the balance variable
    */
   public int getBalance()
   {
       return balance;
   }
   /**
    * DISPLAY_BALANCE METHOD
    * This method will print out the total balance which is the users total gained from
    * the lottery including the subtraction of the lottery ticket price
    */
   public void displayBalance()
   {
       System.out.println("Your balance: £" + getBalance());
   }
   /**
    * COMPARE METHOD
    * This method compares the lottery and user sets and will print out the result
    * and calculate the winnings depending on the number of matches and type of 
    * lottery whilst also printing out the matching set
    */
   public void compare()
   {
       Set<Integer> copyUsers = new HashSet<Integer>(userNumbers);
       copyUsers.retainAll(lotteryNumbers);
       matchChecker = copyUsers.size();
       itr3 = copyUsers.iterator();
       System.out.println("Matching Numbers:");
       System.out.print("[ ");
       while (itr3.hasNext())
       {
           nextNum = itr3.next();
           System.out.print(nextNum + " ");
       }
       System.out.print("]");
       System.out.println(" ");
       if (matchChecker == 0)
       {
           winnings = 0;
           System.out.println("ZERO MATCHES...YOU LOSE!...UNLUCKY!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 0;
               balance += winnings - 2; 
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += 0;
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += 0;
               balance += winnings - 4;
           }
       }
       if (matchChecker == 1)
       {
           System.out.println("ONE MATCH...YOU LOSE!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 0;
               balance += winnings - 2;
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += 0;
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += 0;
               balance += winnings - 4;
           }
       }
       if (matchChecker == 2)
       {
           System.out.println("TWO MATCHES...YOU LOSE!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 0;
               balance += winnings - 2;
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += 0;
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += 0;
               balance += winnings - 4;
           }
       }
       if (matchChecker == 3)
       {
           System.out.println("THREE MATCHES...YOU WON!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 25;
               balance += winnings - 2;
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += (25/5);
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += (25*5);
               balance += winnings - 4;
           }
       }
       if (matchChecker == 4)
       {
           System.out.println("FOUR MATCHES...YOU WON!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 100;
               balance += winnings - 2;
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += (100/5);
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += (100*5);
               balance += winnings - 4;
           }
       }
       if (matchChecker == 5)
       {
           System.out.println("FIVE MATCHES...YOU WON!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 1000;
               balance += winnings - 2;
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += (1000/5);
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += (1000*5);
               balance += winnings - 4;
           }
       }
       if (matchChecker == 6)
       {
           System.out.println("SIX MATCHES...JACKPOT!!!");
           if (LOTTERY_MAX == 50)
           {
               winnings += 1000000;
               balance += winnings - 2;
           }
           else if (LOTTERY_MAX == 25)
           {
               winnings += (1000000/5);
               balance += winnings - 1;
           }
           else if (LOTTERY_MAX == 100)
           {
               winnings += (1000000*5);
               balance += winnings - 4;
           }
       }
   }
   /**
    * AUTO_PLAY METHOD
    * This method will allow the user to run the lottery up to 52 times using the
    * same user set but changing the lottery set to represent a week passing by
    */
   public void autoPlay()
   {
       Scanner a = new Scanner(System.in);
       int timeChecker = 0;
       int time = 0;
       do
       {
       System.out.println("How many weeks would you like to run the lottery?");
       try
       {
           time = a.nextInt();
           if (time < 1 || time > 52)
           {
               System.out.println("Number of weeks is too low or exceeds our policy!");
               System.out.println("Please try again inside the bounds (1 to 52)");
               System.out.println(" ");
           }
       }
       catch (InputMismatchException e)
       { 
           System.out.println("ERROR: Wrong type of input!!! must be an integer");
           a.next();
           continue;
       }
       }
       while (time < 1 || time > 52);
       int won = 0;
       lotteryRange();
       addOwnUserNumbers();
       while (timeChecker < time)
       {
           addRandomLottery();
           compare();
           getWinnings();
           won = won + getWinnings();
           displayWinnings();
           resetWinnings();
           timeChecker++;
       }
       userNumbers.clear();
       if (LOTTERY_MAX == 25)
       {
           int result = won - (time*1); // total winnings - (weeks played * cost of the ticket)
           if (result > 0)
           {
               System.out.println("Your winnings of: £" + result + " exceed the amount spent!");
           }
           else if (result <= 0)
           {
               System.out.println("Your winnings of: £" + result + " do not exceed the amount spent");
           }
       }
       if (LOTTERY_MAX == 50)
       {
           int result = won - (time*2);
           if (result > 0)
           {
               System.out.println("Your winnings of: £" + result + " exceed the amount spent!");
           }
           else if (result <= 0)
           {
               System.out.println("Your winnings of: £" + result + " do not exceed the amount spent");
           }
       }
       if (LOTTERY_MAX == 100)
       {
           int result = won - (time*4);
           if (result > 0)
           {
               System.out.println("Your winnings of: £" + result + " exceed the amount spent!");
           }
           else if (result <= 0)
           {
               System.out.println("Your winnings of: £" + result + " do not exceed the amount spent");
           }
       }
       a.close();
   }
}


