/**
 * The Tester class is used to create the user interface of the menu by using 
 * methods from the Tree class so the user is able to navigate the shop 
 *
 * @author Maks Kijewski
 * @version 22/02/2025
 */
import java.util.Scanner;
import java.util.InputMismatchException;
import java.text.DecimalFormat;
public class Tester
{
    /**
     * FIELD
     * Creates an instance of the shop 
     */
    private Tree shop = new Tree();
    /**
     * MENU METHOD
     * This method is acts as a menu for the user to be able to directly interact with the shop 
     */
    public void menu()
    {
        Scanner s = new Scanner(System.in);
        int choice = 0;
        int id = 0;
        String name;
        double cost;
        int chosenID = 0;
        do
        {
            System.out.println("[MENU]");
            System.out.println("Press 1. Add Item");
            System.out.println("Press 2. Display Tree");
            System.out.println("Press 3. Search");
            System.out.println("Press 4. Display Items");
            System.out.println("Press 5. Display total cost of all items in shop");
            System.out.println("Press 6. Remove Item");
            System.out.println("Press 7. Exit");
            System.out.println("EXTRA: Press 8. Display Items in level order");
            try
            {
                choice = s.nextInt();
            }   
            catch (InputMismatchException e)
            {
                System.out.println("ERROR: Wrong type of input!!! must be an integer");
                s.next();
                continue;
            }
            switch (choice)
            {
                case 1:
                    try
                    {
                        do
                        {
                            System.out.println("Enter ID:");
                            id = s.nextInt();
                            if (id < 1)
                            {
                                System.out.println("ID number must be greater than 0");
                            }
                        }
                        while (id < 1);
                    }
                    catch (InputMismatchException e)
                    {
                        System.out.println("ERROR: Wrong type of input!!! must be an integer");
                        s.next();
                        continue;
                    }
                    
                    s.nextLine();
                    try
                    {
                        do
                        {
                            System.out.println("Enter name:");
                            name = s.nextLine().trim();
                            if (name.isEmpty())
                            {
                                System.out.println("Name cannot be empty");
                            }
                        }
                        while (name.isEmpty());
                    }
                    catch (InputMismatchException e)
                    {
                        System.out.println("ERROR: Wrong type of input!!! must be a String");
                        s.next();
                        continue;
                    }
                    
                    try
                    {
                        do
                        {
                            System.out.println("Enter cost:");
                            cost = s.nextDouble();
                            if (cost < 0)
                            {
                                System.out.println("Cost cannot be less than £0.00");
                            }
                            else
                            {
                                DecimalFormat df = new DecimalFormat("#.##");
                                cost = Double.valueOf(df.format(cost));
                            }
                        }
                        while (cost < 0);
                    }
                    catch (InputMismatchException e)
                    {
                        System.out.println("ERROR: Wrong type of input!!! must be a double");
                        s.next();
                        continue;
                    }
                    s.nextLine();
                    shop.addNode2(id, name, cost);
                    break;
                case 2:
                    shop.showTree();
                    break;
                case 3:
                    System.out.println("Please enter desired item ID:");
                    try
                    {
                        chosenID = s.nextInt();
                    }
                    catch (InputMismatchException e)
                    {
                        System.out.println("ERROR: Wrong type of input!!! must be an integer");
                        s.next();
                        continue;
                    }
                    TreeNode node = shop.find(chosenID);
                    if (node != null)
                    {
                        System.out.println(node.getData());
                    }
                    else
                    {
                        System.out.println("Item not found");
                    }
                    break;
                case 4:
                    shop.showItems();
                    break;
                case 5:
                    shop.getTotal();
                    break;
                case 6:
                    System.out.println("Please enter the ID of the item to be deleted");
                    try
                    {
                        chosenID = s.nextInt();
                    }
                    catch (InputMismatchException e)
                    {
                        System.out.println("ERROR: Wrong type of input!!! must be an integer");
                        s.next();
                        continue;
                    }
                    shop.remove(chosenID, null, shop.getRoot());
                    break;
                case 7:
                    System.out.println("Exiting");
                    break;
                case 8:
                    shop.displayLevelOrder();
                    break;
                default:
                    System.out.println("Input error");
                    break;
            }
        }
        while (choice != 7);
    }
    /**
     * MAIN METHOD
     * This method will call and run the menu method
     */
    public static void main(String[] args)
    {
        Tester run = new Tester();
        run.menu();
    }
}
