/**
 * This class is used to call the methods of the lottery class 
 *
 * @author Maks Kijewski
 * @version 08/02/2025
 */
import java.util.Scanner;
import java.util.InputMismatchException;
public class Tester
{
    /**
     * This method will run the methods in the lottery class without a menu
     */
    public void run()
    {
        Lottery test = new Lottery();
        test.addOwnUserNumbers();
        test.addRandomLottery();
        test.display();
        test.compare();
        test.getWinnings();
        test.displayWinnings();
        test.getBalance();
        test.displayBalance();
        test.resetWinnings();
    }
    /**
     * This method will run the methods in the lottery class using a structured menu
     */
    public void menu()
    {
        Scanner s = new Scanner(System.in);
        int choice = 0;
        Lottery test = new Lottery();
        do
        {
        System.out.println("[MENU]");
        System.out.println("Press 1. Play");
        System.out.println("Press 2. Play (hardcoded)");
        System.out.println("Press 3. Auto play");
        System.out.println("Press 4. Display Balance");
        System.out.println("Press 5. EXIT");
        try
        {
            choice = s.nextInt();
        }
        catch (InputMismatchException e)
        {
            System.out.println("ERROR: Wrong type of input!!! must be an integer");
            s.next();
            continue;
        }
        switch (choice)
        {
            case 1:
                test.lotteryRange();
                test.addRandomLottery();
                test.addOwnUserNumbers(); 
                test.display();
                test.compare();
                test.getWinnings();
                test.displayWinnings();
                test.resetWinnings();
                break;
            case 2:
                test.addLotteryNumbers();
                test.addUserNumbers();
                test.display();
                test.compare();
                test.getWinnings();
                test.displayWinnings();
                test.resetWinnings();
                break;
            case 3:
                test.autoPlay();
                break;
            case 4:
                test.getBalance();
                test.displayBalance();
                break;
            case 5:
                break;
            default:
                System.out.println("Input error");
                break;
        }
        }
        while (choice != 5);
    }
    /**
     * MAIN METHOD
     */
    public static void main(String[] args)
    {
        Tester t = new Tester();
        //t.run();
        t.menu();
    }
}
